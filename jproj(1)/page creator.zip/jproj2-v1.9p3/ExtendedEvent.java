
import java.io.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.regex.*;
import java.io.*;
import java.util.*;
import java.util.Properties;
import java.util.regex.*;
import java.lang.*;
import com.ticketnetwork.webservices2.*;
import javax.xml.*;
import java.lang.reflect.Array;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import javax.xml.*;
import java.sql.Connection;
import java.sql.*;
import java.sql.DriverManager;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.io.*;
import java.util.*;
import java.util.Properties;
import java.util.regex.*;
import java.lang.*;
import com.ticketnetwork.webservices2.*;
import javax.xml.*;
import java.lang.reflect.Array;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


public class ExtendedEvent{
    Event event=null;
    String category=null;
    
}