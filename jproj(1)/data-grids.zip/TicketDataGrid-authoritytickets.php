<?php
ini_restore('include_path');

$server1='204.12.25.164';
$port1='3306';
$username1='jdata';
$password1='jjoaky11';


$sys1 = $server1.":".$port1;
$sys2 = $server2.":".$port2;
$sys3 = $server3.":".$port3;

if(!strcmp($sys1,":")==0){
// echo 'trying con1 ';
if (!$link = mysql_connect($sys1,$username1,$password1,true)) 
{
// echo 'con2 '; 
if (!$link = mysql_connect($sys2,$username2,$password2,true)) 
{
// echo 'con3'; 
if (!$link = mysql_connect($sys3,$username3,$password3,true)) 
{
 echo "<table cellspacing=0 cellpadding=3 rules=all border=1 id=TicketDataGrid style=border-color:Black;border-width:1px;border-style:solid;font-family:Verdana;font-size:8pt;font-color:#FFFFFF;border-collapse:collapse;><tr style=background-color:#3332CC;><td>Event</td><td>Venue</td><td>Date/Time</td><td> </td>";
 echo "<tr><td width=330>Sorry, an error occured while processing your request. Please try again later.</td><td width=100> </td><td width=100> </td><td width=40> </td></tr>";
 echo "</tr></tr></table>";
 exit;
}
}
}

if (!mysql_select_db($dbname, $link)) {
   echo "<table cellspacing=0 cellpadding=3 rules=all border=1 id=TicketDataGrid style=border-color:Black;border-width:1px;border-style:solid;font-family:Verdana;font-size:8pt;font-color:#FFFFFF;border-collapse:collapse;><tr style=background-color:#3332CC;><td>Event</td><td>Venue</td><td>Date/Time</td><td> </td>";
   echo "<tr><td width=330>Sorry, an error occured while processing your request. Please try again later.</td><td width=100> </td><td width=100> </td><td width=40> </td></tr>";
   echo "</tr></tr></table>";
   mysql_close($link);
   exit;
}

$sql = 'SELECT * FROM events where true ';
if(!(strcmp($eventName,"")==0)){
$eventName=str_replace("'","\\'",$eventName);
$sql = $sql.' and Name like \'%'.$eventName.'%\' ';
}
if(!(strcmp($performerName,"")==0)){
$performerName=str_replace("'","\\'",$performerName);
$sql = $sql.' and Name like \'%'.$performerName.'%\' ';
}
if(!(strcmp($city,"")==0)){
$city=str_replace("'","\\'",$city);
$sql = $sql.' and City=\''.$city.'\' ';
}
if(!(strcmp($venue,"")==0)){
$venue=str_replace("'","\\'",$venue);
$sql = $sql.' and Venue=\''.$venue.'\' ';
}
if(!(strcmp($stateProvince,"")==0)){
$stateProvince=str_replace("'","\\'",$stateProvince);
$sql = $sql.' and StateProvince=\''.$stateProvince.'\' ';
}
if(!(strcmp($ParentCategoryID,"")==0)){
$sql = $sql.' and ParentCategoryID='.$ParentCategoryID.' ';
}
if(!(strcmp($ChildCategoryID,"")==0)){
$sql = $sql.' and ChildCategoryID='.$ChildCategoryID.' ';
}
if(!(strcmp($GrandchildCategoryID,"")==0)){
$sql = $sql.' and GrandchildCategoryID='.$GrandchildCategoryID.' ';
}
if(!(strcmp($BeginDate,"")==0)){

if(strcmp($BeginDate,"today")==0){
 //$sql = $sql.' and Curdate() <= Date ';
  // $sql = $sql.' and '.date('Y-m-d').' <= Date ';
   $sql = $sql.' and STR_TO_DATE(\''.date('m-d-y').'\',\'%m-%d-%Y\') <= Date ';
}else{
	
        $sql = $sql.' and STR_TO_DATE(\''.$BeginDate.'\',\'%m/%d/%Y\') <= Date ';
}

}
if(!(strcmp($EndDate,"")==0)){

if(strcmp($EndDate,"today")==0){
    
 //$sql = $sql.' and Curdate() >= Date ';
 //$sql = $sql.' and '.date('Y-m-d').' >= Date ';
   $sql = $sql.' and STR_TO_DATE(\''.date('m-d-y').'\',\'%m-%d-%Y\') >= Date ';
}else{
	$sql = $sql.' and STR_TO_DATE(\''.$EndDate.'\',\'%m/%d/%Y\') >= Date ';
}

}

$sql = $sql.' order by Date ';
if(!(strcmp($numReturned,"")==0)){
$sql = $sql.' LIMIT '.$numReturned.';';
}


//echo "query: ".$sql;
$result = mysql_query($sql, $link);

if (($result)||(mysql_errno == 0))
{

  if (mysql_num_rows($result)>0)
  {
       echo "<table cellspacing=0 cellpadding=6 rules=all border=1 id=TicketDataGrid style=border-color:Black;border-width:1px;border-style:solid;font-family:Verdana;font-size:8pt;border-collapse:collapse;><tr style=background-color:#3332CC;color:#FFFFFF;><td>Event</td><td>Venue</td><td>Date/Time</td><td> </td>";
 
    while ($rows = mysql_fetch_array($result,MYSQL_ASSOC))
    {
        
	$weekday = strftime("%A", strtotime($rows["Date"]));  
	$date = strftime("%D", strtotime($rows["Date"]));  
	$day = strftime("%d", strtotime($rows["Date"]));  
	$month = strftime("%m", strtotime($rows["Date"]));  
	$year = strftime("%Y", strtotime($rows["Date"]));  
	$hour = strftime("%I", strtotime($rows["Date"])); 
	$minute = strftime("%M", strtotime($rows["Date"]));
        $ampm = strftime("%p", strtotime($rows["Date"]));  
	$time = $hour.":".$minute." ".$ampm;
	if(($hour==3) && ($minute==30) && (strcmp('AM',$ampm)==0)){
		$time = "TBA";
	}
	   
	echo "<tr><td>".$rows["Name"]."</td><td>".$rows["Venue"]."<br>".$rows["City"].",".$rows["StateProvince"]."</td><td>".$weekday."<br>".$month."/".$day."/".$year."<br>".$time."</td><td><a href=".$buyNowURL.$rows["ID"]."><div align=center><u><strong><font size=4>View<BR>Tickets</font></strong></u></div></a></td></tr>";

    }
     echo "</tr></tr></table>";
    
  }else{
 
	echo "";
  }
  
}else{

 echo "<table cellspacing=0 cellpadding=3 rules=all border=1 id=TicketDataGrid style=border-color:Black;border-width:1px;border-style:solid;font-family:Verdana;font-size:8pt;font-color:#FFFFFF;border-collapse:collapse;><tr style=background-color:#3332CC;><td>Event</td><td>Venue</td><td>Date/Time</td><td> </td>";
 echo "<tr><td width=330>Sorry, an error occured while processing your request. Please try again later.</td><td width=100> </td><td width=100> </td><td width=40> </td></tr>";
 echo "</tr></tr></table>";
} 


}else{

 echo "<table cellspacing=0 cellpadding=3 rules=all border=1 id=TicketDataGrid style=border-color:Black;border-width:1px;border-style:solid;font-family:Verdana;font-size:8pt;font-color:#FFFFFF;border-collapse:collapse;><tr style=background-color:#3332CC;><td>Event</td><td>Venue</td><td>Date/Time</td><td> </td>";
 echo "<tr><td width=330>Sorry, an error occured while processing your request. Please try again later.</td><td width=100> </td><td width=100> </td><td width=40> </td></tr>";
 echo "</tr></tr></table>";

}
mysql_free_result($result);
mysql_close($link);
?>

