@javax.xml.bind.annotation.XmlSchema(namespace = "http://tnwebservices-test.ticketnetwork.com/tnwebservice/v3.0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ticketnetwork.tnwebservices_test.tnwebservice.v3;
